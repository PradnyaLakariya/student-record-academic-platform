# Student Record and Academic Management Platform

A student implementation of the Unit 4 Infrastructure Automation assignment. The project uses Flask for a small REST API, Docker to package the app, Terraform to provision AWS infrastructure, and Ansible to configure and deploy the app on Ubuntu EC2.

## Architecture

- **Application:** Flask API with health, student, and marks endpoints
- **Container:** Docker image listening on port `8080`
- **Reverse proxy:** Nginx on port `80`, forwarding requests to the container
- **Infrastructure:** AWS VPC (`10.1.0.0/16`), public subnet (`10.1.0.0/24`), security group, EC2, and a private S3 bucket
- **Configuration management:** Ansible roles for common packages, Docker, Nginx, and the application

> This is an educational starter project. The API uses in-memory sample data; it is not a production student information system and does not provide authentication or persistent database storage.

## Repository layout

```text
student-record-academic-platform/
├── app/
│   ├── app.py
│   ├── requirements.txt
│   └── Dockerfile
├── terraform/
│   ├── versions.tf
│   ├── variables.tf
│   ├── main.tf
│   ├── outputs.tf
│   └── terraform.tfvars.example
├── ansible/
│   ├── ansible.cfg
│   ├── inventory.ini.example
│   ├── site.yml
│   └── roles/
│       ├── common/tasks/main.yml
│       ├── docker/tasks/main.yml
│       ├── nginx/tasks/main.yml
│       └── student_app/tasks/main.yml
├── scripts/
│   ├── make_inventory.sh
│   └── make_inventory.ps1
├── docs/
│   └── deployment-and-testing.md
├── .gitignore
└── LICENSE
```

## Requirements

- AWS account with access to create VPC, EC2, security groups, and S3 resources
- AWS CLI configured (`aws configure`) or another supported AWS credentials method
- Terraform 1.7 or newer
- Ansible 2.16 or newer on a Linux control node (Ubuntu/WSL is recommended; Ansible does not run natively as a normal Windows control node)
- An EC2 key pair already created in the AWS region you choose
- Git

## 1. Run the API locally

From the repository root:

```bash
cd app
python -m venv .venv
```

Activate the environment:
- Windows PowerShell: `.\.venv\Scripts\Activate.ps1`
- Linux/WSL: `source .venv/bin/activate`

Then run:

```bash
pip install -r requirements.txt
python app.py
```

Open `http://127.0.0.1:8080/api/health`. The API listens on port `8080`.

## 2. Provision AWS resources with Terraform

Change to the Terraform directory:

```bash
cd terraform
cp terraform.tfvars.example terraform.tfvars
```

Edit `terraform.tfvars` and set `key_name` to an existing EC2 key pair name. Set `ssh_cidr` to your current public IP in CIDR format, for example `203.0.113.10/32` (replace this documentation IP with your own IP). Do not open SSH to everyone unless you have a specific, temporary reason.

Configure AWS credentials before continuing. Then run:

```bash
terraform init
terraform fmt -recursive
terraform validate
terraform plan
terraform apply
```

Review the plan and type `yes` only if the resources and costs are acceptable. Get the server IP:

```bash
terraform output -raw app_public_ip
```

The configuration creates billable AWS resources. Check AWS pricing and your account's free-tier eligibility before applying.

## 3. Configure the server using Ansible

Run Ansible from Ubuntu or WSL. Install the required collection once with `ansible-galaxy collection install -r ansible/requirements.yml`. Ensure your EC2 private key is available to that environment and has restrictive permissions (`chmod 400 /path/to/key.pem` on Linux/WSL).

From the repository root, generate the inventory using the public IP from Terraform:

```bash
bash scripts/make_inventory.sh
```

The script expects the `terraform` command and AWS project folder structure to be available. It reads `terraform output -raw app_public_ip` and writes `ansible/inventory.ini`.

Set the private key path in `ansible/ansible.cfg` or pass it on the command line. Example:

```bash
cd ansible
ansible -i inventory.ini student_servers -m ping
ansible-playbook -i inventory.ini site.yml
```

If your key is outside the default SSH agent, use:

```bash
ansible-playbook -i inventory.ini site.yml --private-key /path/to/key.pem
```

After the playbook completes, visit `http://YOUR_EC2_PUBLIC_IP/api/health`.

## 4. Test API endpoints

```bash
curl http://YOUR_EC2_PUBLIC_IP/api/health
curl http://YOUR_EC2_PUBLIC_IP/api/students
curl -X POST http://YOUR_EC2_PUBLIC_IP/api/marks \
  -H "Content-Type: application/json" \
  -d '{"student_id": 1, "subject": "Statistics", "marks": 86}'
```

The starter API stores newly submitted records in memory, so data resets when the app container restarts.

## 5. Clean up AWS resources

When you have finished testing, from the `terraform` directory run:

```bash
terraform destroy
```

Review the destroy plan and confirm only if you intend to delete the resources. The S3 bucket is configured with `force_destroy = true` for this disposable assignment environment; do not use that setting for important data.

## Security notes

- Restrict SSH ingress using `ssh_cidr`.
- The app's port `8080` is exposed for assignment testing; for a hardened deployment, remove public access to `8080` and permit only Nginx traffic on port `80`.
- The S3 bucket is private and has public access blocked.
- Terraform state can contain infrastructure details. Never commit state files, private keys, credentials, or local `.tfvars` files.
